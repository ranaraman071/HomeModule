import 'package:flutter/material.dart';

class AppColors {
  static const Color whiteColor = Colors.white;
  static const Color redColors = Colors.red;

  static const Color grey = Color(0xff8F9093);
  static const Color backgroundcream = Color.fromRGBO(255, 249, 249, 1);



}