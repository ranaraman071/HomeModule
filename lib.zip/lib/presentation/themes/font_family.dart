class FontFamily{
  static const inter = "inter";
}