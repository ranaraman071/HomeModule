class AssetsPics {
  static const String cyb = "assets/images/cyb.jpeg";
  static const String site_click = "assets/images/site_click.png";
  static const String shape = "assets/icon/Shape.svg";
}