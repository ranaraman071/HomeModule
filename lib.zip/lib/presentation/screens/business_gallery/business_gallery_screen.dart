import 'package:home_module/presentation/widgets/common_text.dart';
import 'package:flutter/material.dart';

class BusinessGalleryScreen extends StatefulWidget {
  const BusinessGalleryScreen({super.key});

  @override
  State<BusinessGalleryScreen> createState() => _BusinessGalleryScreenState();
}

class _BusinessGalleryScreenState extends State<BusinessGalleryScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(child: CommonText(text: "Business Gallery"),),
    );
  }
}
