import 'package:flutter/material.dart';
import 'package:home_module/presentation/widgets/common_text.dart';

class ReviewScreen extends StatefulWidget {
  const ReviewScreen({super.key});

  @override
  State<ReviewScreen> createState() => _ReviewScreenState();
}

class _ReviewScreenState extends State<ReviewScreen> {
  @override
  Widget build(BuildContext context) {
    final size=MediaQuery.of(context).size;
    return Column(
      // mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: size.height*0.03),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: size.width*0.04),
          child: CommonText(text: "Contact",fontWeight: FontWeight.w600,fontSize: size.width*0.045),
        ),
        const Divider(),
        buildContainerOption(size,Icons.call,"+1(415)885 4605"),
        const Divider(),
        buildContainerOption(size,Icons.mail,"examplehere@gmail.com"),
        const Divider(),
        buildContainerOption(size,Icons.circle,"centralcomputers.com"),
        const Divider(),
        Container(
          padding: EdgeInsets.symmetric(horizontal: size.width*0.06),
          height: size.height*0.07,
          width: size.width,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Icon(Icons.child_friendly,size: size.height*0.04,),
              SizedBox(width: size.width*0.04),
              Icon(Icons.child_friendly,size: size.height*0.04),
            ],),
        ),
        SizedBox(height: size.height*0.5,)
      ],
    );
  }

  Container buildContainerOption(Size size,IconData icn,String txt) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: size.width*0.1),
      height: size.height*0.07,
      width: size.width,
      child:  Row(
        children: [
          Icon(icn,size: size.width*0.08),
          SizedBox(width: size.width*0.15),
          CommonText(text: txt,fontSize: size.width*0.04,fontWeight: FontWeight.w600,)
        ],),
    );
  }
}
