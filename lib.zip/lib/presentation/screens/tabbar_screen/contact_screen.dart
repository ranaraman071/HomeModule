import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:home_module/presentation/themes/icons.dart';
import 'package:home_module/presentation/widgets/common_text.dart';

class ContactScreen extends StatefulWidget {
  const ContactScreen({super.key});

  @override
  State<ContactScreen> createState() => _ContactScreenState();
}

class _ContactScreenState extends State<ContactScreen> {
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Column(
      // mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(height: size.height * 0.03),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: size.width * 0.04),
          child: CommonText(
              text: "Contact",
              fontWeight: FontWeight.w600,
              fontSize: size.width * 0.045),
        ),
        const Divider(),
        buildContainerOption(size, Icn.phone, "+1(415)885 4605"),
        const Divider(),
        buildContainerOption(size, Icn.email_rounded, "examplehere@gmail.com"),
        const Divider(),
        buildContainerOption(size, Icn.globe, "centralcomputers.com"),
        const Divider(),
        Container(
          padding: EdgeInsets.symmetric(horizontal: size.width * 0.06),
          height: size.height * 0.07,
          width: size.width,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Icon(
                Icn.twitter,
                size: size.height * 0.04,
              ),
              SizedBox(width: size.width * 0.04),
              Icon(Icn.instagram, size: size.height * 0.04),
            ],
          ),
        ),
        SizedBox(
          height: size.height * 0.5,
        )
      ],
    );
  }

  Container buildContainerOption(Size size, IconData icn, String txt) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: size.width * 0.1),
      height: size.height * 0.07,
      width: size.width,
      child: Row(
        children: [
          Icon(icn, size: size.width * 0.08),
          SizedBox(width: size.width * 0.15),
          icn == Icn.globe
              ? Column(
            mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(txt, style: TextStyle(
                  fontSize: size.width * 0.04,
                  fontWeight: FontWeight.w600,
                  color: Colors.deepPurpleAccent)),
                  Container(width: size.width*0.44,height: size.width*0.004,color: Colors.deepPurpleAccent)
                ],
              )
              : CommonText(
                  text: txt,
                  fontSize: size.width * 0.04,
                  fontWeight: FontWeight.w600)
        ],
      ),
    );
  }
}
