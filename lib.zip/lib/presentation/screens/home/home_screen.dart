import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:home_module/data/providers/home_bloc/headerBox.bloc/headerBox_event.dart';
import 'package:home_module/data/providers/home_bloc/headerBox.bloc/headerBox_state.dart';
import 'package:home_module/data/providers/home_bloc/tabBar_bloc.dart';
import 'package:home_module/data/providers/home_bloc/headerBox.bloc/upper_detail_bloc.dart';
import 'package:home_module/presentation/screens/business_gallery/business_gallery_screen.dart';
import 'package:home_module/presentation/screens/tabbar_screen/contact_screen.dart';
import 'package:home_module/presentation/screens/tabbar_screen/etc_screen.dart';
import 'package:home_module/presentation/screens/tabbar_screen/review_screen.dart';
import 'package:home_module/presentation/themes/color_constants.dart';
import 'package:home_module/presentation/themes/icons.dart';
import 'package:home_module/presentation/themes/images.dart';
import 'package:home_module/presentation/widgets/common_text.dart';
import 'package:home_module/presentation/widgets/common_url.dart';
import 'package:home_module/utils/navigator_services.dart';
import 'package:flutter/material.dart';
import 'package:home_module/utils/send_to_url.dart';

class Homescreen extends StatefulWidget {
  const Homescreen({super.key});

  @override
  State<Homescreen> createState() => _HomescreenState();
}

class _HomescreenState extends State<Homescreen> with SingleTickerProviderStateMixin {
  ScrollController _scrollController = ScrollController();
  bool _isCollapsed = false;
  TabController? _tabController;
  NavigationCubit? navCubit;
  AppBarBloc? appBarBloc;

  @override
  void initState() {
    navCubit=context.read<NavigationCubit>();
    appBarBloc=context.read<AppBarBloc>();

    super.initState();
    _tabController = TabController(length: 3, vsync: this, initialIndex: navCubit!.state);
    _scrollController.addListener(() {
      if (_scrollController.hasClients) {
        double offset = _scrollController.offset;
        if (offset > 350.0 && !_isCollapsed) {
          _isCollapsed = true;
          appBarBloc!.add(AppBarCollapsed(val: true));
        } else if (offset < 350.0 && _isCollapsed) {
          _isCollapsed = false;
          appBarBloc!.add(AppBarCollapsed(val: false));
        }
      }
    });
  }

  final List tabData = [
    const ReviewScreen(),
    const ContactScreen(),
    const ETCScreen(),
  ];


  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor: Colors.white,
        body: CustomScrollView(
          controller: _scrollController,
          physics: const ClampingScrollPhysics(),
          slivers: [
            SliverAppBar(
              backgroundColor: Colors.white,
              pinned: true,
              expandedHeight: size.height * 0.76,
              collapsedHeight: size.width * 0.3,
              flexibleSpace: BlocBuilder<AppBarBloc, AppBarState>(
                  builder: (context, state) {
                return FlexibleSpaceBar(
                    title: Container(
                      height: state.val ? size.width * 0.18 : 0,
                      width: state.val ? size.width : 0,
                      margin: EdgeInsets.only(bottom: size.width * 0.12, left: size.width * 0.06, right: size.width * 0.06),
                      padding: EdgeInsets.only(left: size.width * 0.035),
                      decoration: BoxDecoration(
                        color: AppColors.backgroundcream,
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.25),
                            blurRadius: 3,
                            offset: const Offset(-1, 5),
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: size.width * 0.08,
                            height: size.width * 0.08,
                            margin: EdgeInsets.only(bottom: size.width * 0.02),
                            decoration: BoxDecoration(
                                color: AppColors.grey,
                                borderRadius: BorderRadius.circular(10)),
                          ),
                          SizedBox(width: size.width * 0.03),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              SizedBox(height: size.width * 0.03),
                              CommonText(
                                  text: "[Buisiness Name]",
                                  color: Colors.black,
                                  fontSize: size.width * 0.04,
                                  fontWeight: FontWeight.w600),
                              SizedBox(height: size.width * 0.015),
                              Row(
                                children: [
                                  CommonText(
                                      text: "Closed",
                                      color: AppColors.redColors,
                                      fontSize: size.width * 0.035,
                                      fontWeight: FontWeight.w600),
                                  SizedBox(width: size.width * 0.03),
                                  CommonText(
                                      text: "[Operating Info]",
                                      color: Colors.black,
                                      fontSize: size.width * 0.03,
                                      fontWeight: FontWeight.w600),
                                ],
                              ),
                            ],
                          ),
                          SizedBox(width: size.width * 0.15),
                          Container(
                            color: Colors.transparent,
                            child: Icon(
                              Icn.adress,
                              size: size.width * 0.08,
                            ),
                          )
                        ],
                      ),
                    ),
                    centerTitle: true,
                    background: Stack(
                      children: [
                        Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            // Header Image widget
                            headerImage(size),

                            // Store Description one line
                            buildDescriptionContainer(size),

                            // Adress area
                            buildAdressContainer(size),

                            // Announcement area
                            buildAnnouncementContainer(size),
                          ],
                        ),
                      ],
                    ));
              }),
              bottom: TabBar(
                onTap: (index) {
                  navCubit?.selectTab(index);
                  // appBarBloc!.add(AppBarCollapsed(val: false));
                },
                tabs: const [
                  Tab(text: "Reviews"),
                  Tab(text: "Contact"),
                  Tab(text: "Etc.")
                ],
                controller: _tabController,
                isScrollable: false,
                labelColor: Colors.black,
                unselectedLabelColor: Colors.black,
                indicatorColor: Colors.red,
                labelStyle: TextStyle(color: Colors.black, fontSize: size.width * 0.04, fontWeight: FontWeight.w600),
                indicatorSize: TabBarIndicatorSize.label,
                indicatorWeight: 1.0,
                dividerHeight: 2.0,
                splashFactory: NoSplash.splashFactory,
              ),
            ),
            SliverList(
              delegate: SliverChildBuilderDelegate((BuildContext context, int index) {
                return BlocBuilder<NavigationCubit,int>(builder: (context,state){
                  return Column(children: [
                    tabData[state],
                  ]);
                });
              }, childCount: 1),
            ),
          ],
        ),
      ),
    );
  }

  Widget headerImage(Size size) {
    return Container(
      width: size.width,
      height: size.height * 0.3,
      color: Colors.red,
      child: GestureDetector(
        onTap: () {
          NavigatorService().push(const BusinessGalleryScreen());
        },
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.asset(AssetsPics.cyb, fit: BoxFit.cover),
            Container(
              width: double.infinity,
              height: double.infinity,
              color: Colors.black.withOpacity(0.5),
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: size.width * 0.04, vertical: size.width * 0.04),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      CommonText(
                          text: "[Buisiness Name]",
                          color: AppColors.whiteColor,
                          fontSize: size.width * 0.045,
                          fontWeight: FontWeight.w600),
                      SizedBox(height: size.width * 0.015),
                      Row(
                        children: [
                          CommonText(
                              text: "Closed",
                              color: AppColors.redColors,
                              fontSize: size.width * 0.038,
                              fontWeight: FontWeight.w600),
                          SizedBox(width: size.width * 0.05),
                          CommonText(
                              text: "[Operating Info]",
                              color: AppColors.whiteColor,
                              fontSize: size.width * 0.03,
                              fontWeight: FontWeight.w600),
                        ],
                      ),
                    ],
                  ),
                  GestureDetector(
                    onTap: () {
                      NavigatorService().push(const BusinessGalleryScreen());
                    },
                    child: Container(
                        color: Colors.transparent,
                        child: Icon(Icn.camera_alt_outlined, color: AppColors.whiteColor, size: size.width * 0.08)),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget buildDescriptionContainer(Size size) {
    return Container(
      alignment: Alignment.centerLeft,
      padding: EdgeInsets.symmetric(horizontal: size.width * 0.04),
      height: size.width * 0.1,
      width: size.width,
      child: CommonText(
        text: "Computer Store,Electronic etc. [Store Description]",
        fontSize: size.width * 0.037,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        fontWeight: FontWeight.w600,
      ),
    );
  }

  Widget buildAdressContainer(Size size) {
    return Container(
      alignment: Alignment.center,
      height: size.width * 0.15,
      width: size.width,
      margin: EdgeInsets.symmetric(horizontal: size.width * 0.04, vertical: size.width * 0.01),
      child:  TextFormField(
        readOnly: true,
        onTap: () {
          SendUsertoUrl.urlCall(CommonUrl.googleMap);
        },
        textAlign: TextAlign.justify,
        decoration: InputDecoration(
            border: InputBorder.none,
            prefixIcon: Icon(Icn.adress, size: size.width * 0.08),
            hintText: "Address",
            hintStyle: TextStyle(fontSize: size.width * 0.04)),
      ),
    );
  }

  Widget buildAnnouncementContainer(Size size) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: size.width * 0.03, vertical: size.width * 0.02),
      padding: EdgeInsets.symmetric(horizontal: size.width * 0.03, vertical: size.width * 0.02),
      height: size.height * 0.32,
      width: size.width,
      child: Column(
        children: [
          Container(
            alignment: Alignment.center,
            height: size.height * 0.22,
            padding: EdgeInsets.only(left: size.width*0.04),
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(30)),
            child: Stack(
              children: [
                Positioned(top: size.width*0.01, left:size.width* -0.004, right:  size.width*0.01, bottom: size.width* -0.004, child: SvgPicture.asset(AssetsPics.shape,height: size.width,   colorFilter: ColorFilter.mode(Colors.black.withOpacity(0.3), BlendMode.srcATop),)),
                SvgPicture.asset(AssetsPics.shape,height: size.width),
                Container(
                  margin: EdgeInsets.only(left: size.width*0.07,right: size.width*0.045),
                  alignment: Alignment.center,
                  height: size.height*0.2,
                    width: size.height*0.4,
                    child: CommonText(text: "Announcements ", fontSize: size.width * 0.04, fontWeight: FontWeight.w600,maxLines: 7,overflow: TextOverflow.ellipsis)),
              ],
            ),
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                width: size.width * 0.1,
                height: size.width * 0.1,
                decoration: BoxDecoration(color: AppColors.grey, borderRadius: BorderRadius.circular(12)),
              ),
              CommonText(
                text: "Last Updated 3/3/24",
                color: AppColors.grey,
                fontSize: size.width * 0.034,
                fontStyle: FontStyle.italic,
              )
            ],
          ),
        ],
      ),
    );
  }
}
