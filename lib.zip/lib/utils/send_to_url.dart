import 'package:url_launcher/url_launcher.dart';

class SendUsertoUrl {
  static void urlCall(String txt) async {
    final Uri googleMapsUrl = Uri.parse(txt);
    if (await canLaunchUrl(googleMapsUrl)) {
      await launchUrl(googleMapsUrl, mode: LaunchMode.externalApplication);
    } else {
      throw 'Could not open the map.';
    }
  }
  }
